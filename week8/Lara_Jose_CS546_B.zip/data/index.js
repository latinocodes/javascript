const peopleData = require("./people");

module.exports = {
  people: peopleData,
};

