const education = [
        {
            "schoolName": "Stevens Instite of Technology",
            "degree": "Master of Science",
            "favoriteClass": "CS546 - Web programming I",
            "favoriteMemory": "When we have to combine two lecture on one night, so we don't have to come in on saturday, lol."
        },
        {
            "schoolName": "Regis University",
            "degree": "Bachelor of Science",
            "favoriteClass": "Intro. to programming Languages",
            "favoriteMemory": "One time, Some of my friends had to walk about 10 miles because there was not bus running due to storm the day before."
        },
        {
            "schoolName": "Hudson County Community College",
            "degree": "Associate of Science",
            "favoriteClass": "Intro. to programmming",
            "favoriteMemory": "The first time I wrote a program, it was like love at first site."
        }
    ]

module.exports = education;