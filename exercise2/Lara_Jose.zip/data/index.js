const peopleData = require('./peopleData')

module.exports = {
    peopleData
}