const postsData = require("./posts");
const animalsData = require("./animals");

module.exports = {
  animals: animalsData,
  posts: postsData
};
